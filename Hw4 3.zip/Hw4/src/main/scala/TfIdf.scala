import org.apache.spark.sql.SparkSession

import scala.math.log

object TfIdf {

  def main(args: Array[String]): Unit = {
    val spark = SparkSession.builder
      .appName("TfIdf")
      .master("spark://MacBooks-MacBook-Pro.local:7077")
      .config("spark.sql.warehouse.dir", "target/spark-warehouse")
      .getOrCreate
    import spark.implicits._

    val Train = spark.read
      .option("header", "true")
      .option("multiLine","true")
      .option("escape", "\"")
      .csv("/Users/macbook/Desktop/Hw4/resources/facebook_data/Train/Train.csv")
    Train.show

    val data_sel = Train.select("Id","Title", "Body").rdd
    val tf = data_sel
      .map(row => (row(0), row(1) + " " + row(2))) // add body to title
      .flatMapValues(_.toString.split(" "))  // split words by space
      .map(record => (record._1,record._2,1) ) // add one to end in order t count
      .map(record => (record._1 + " " + record._2, record._3) ) //I did this to be able to count word freq nin documents

    //tf.foldByKey(0)(_+_) // count numbers

    println(tf.count())
    tf.persist // persist to hard

    val docs_num = data_sel.count
    val idf = data_sel
      .map(row => (row(0), row(1) + " " + row(2))) // add body to title
      .flatMapValues(_.toString.split(" ")) // split words by space
      .map(record => (record._2, record._1))
      .distinct // count words in distinct documents
      .map(record => record._1)
      .countByValue //count words
      .map(record => (record._1, log(record._2 + 1 / docs_num + 1))) // idf function implementation


    val result = tf.map{
      record =>
        val split_record = record._1.split(" ")
        (split_record(1), split_record(0), record._2)
    }

    val tf_idf = result.map {
      record =>
        idf.get(record._1).map {
          idf_score => (record._1, record._2, record._3 * idf_score)
        }
    }

    tf_idf.map { _ match {
      case Some(value) => value
      case None => (0, 0, 0)
    }
    }
      .map{
        record => (record._1.toString, record._2.toString.toInt, record._3.toString.toFloat)
      }
      // .sortBy(_._3)
      .take(200)
      .foreach(record => println("token, id, tfIdf --> " + record))
  }

}
